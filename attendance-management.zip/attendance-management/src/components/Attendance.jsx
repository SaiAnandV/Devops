// Displays and updates attendance for ONE student.
// All data and handlers arrive through props.
function Attendance({ percentage, attended, total, status, onPresent, onAbsent }) {
  const eligible = percentage >= 75;

  return (
    <div className="attendance">
      <div className="percent-row">
        <span className="percent">{percentage}%</span>
        <span className={`badge ${eligible ? "ok" : "bad"}`}>
          {eligible ? "Eligible" : "Not Eligible"}
        </span>
      </div>

      <div className="bar">
        <div
          className={`bar-fill ${eligible ? "ok" : "bad"}`}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>

      <p className="muted">
        {attended} of {total} classes attended
        {status && <> · Today: <strong>{status}</strong></>}
      </p>

      <div className="buttons">
        <button
          className={`btn present ${status === "Present" ? "active" : ""}`}
          onClick={onPresent}
        >
          Present
        </button>
        <button
          className={`btn absent ${status === "Absent" ? "active" : ""}`}
          onClick={onAbsent}
        >
          Absent
        </button>
      </div>
    </div>
  );
}

export default Attendance;
