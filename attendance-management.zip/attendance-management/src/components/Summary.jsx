function Summary({ total, present, absent, eligible, notEligible }) {
  const items = [
    { label: "Total Students", value: total, cls: "" },
    { label: "Present Today", value: present, cls: "ok" },
    { label: "Absent Today", value: absent, cls: "bad" },
    { label: "Eligible", value: eligible, cls: "ok" },
    { label: "Not Eligible", value: notEligible, cls: "bad" },
  ];

  return (
    <section className="summary">
      {items.map((i) => (
        <div key={i.label} className={`stat ${i.cls}`}>
          <span className="stat-value">{i.value}</span>
          <span className="stat-label">{i.label}</span>
        </div>
      ))}
    </section>
  );
}

export default Summary;
