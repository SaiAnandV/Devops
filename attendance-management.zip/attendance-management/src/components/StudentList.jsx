import StudentCard from "./StudentCard";

// Pass student details down to each StudentCard with .map()
function StudentList({ students, getPercentage, onMark }) {
  if (students.length === 0) {
    return <p className="empty">No students match your search.</p>;
  }

  return (
    <div className="grid">
      {students.map((s) => (
        <StudentCard
          key={s.roll}
          name={s.name}
          roll={s.roll}
          branch={s.branch}
          percentage={getPercentage(s)}
          attended={s.attended + (s.status === "Present" ? 1 : 0)}
          total={s.total + (s.status ? 1 : 0)}
          status={s.status}
          onPresent={() => onMark(s.roll, "Present")}
          onAbsent={() => onMark(s.roll, "Absent")}
        />
      ))}
    </div>
  );
}

export default StudentList;
