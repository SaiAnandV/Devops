import Attendance from "./Attendance";

function StudentCard({ name, roll, branch, percentage, attended, total, status, onPresent, onAbsent }) {
  const low = percentage < 75;

  return (
    <div className={`card ${low ? "low" : ""}`}>
      <div className="card-top">
        <div>
          <h3>{name}</h3>
          <p className="muted">{roll} · {branch}</p>
        </div>
        {low && <span className="warn">Below 75%</span>}
      </div>

      <Attendance
        percentage={percentage}
        attended={attended}
        total={total}
        status={status}
        onPresent={onPresent}
        onAbsent={onAbsent}
      />
    </div>
  );
}

export default StudentCard;
