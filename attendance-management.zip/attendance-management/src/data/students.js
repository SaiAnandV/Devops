// attended / total = classes held so far (total is 100, so attended equals the %).
// status = today's session mark: null | "Present" | "Absent"
export const initialStudents = [
  { roll: "CSE101", name: "Rahul",  branch: "CSE", attended: 82, total: 100, status: null },
  { roll: "CSE102", name: "Priya",  branch: "CSE", attended: 68, total: 100, status: null },
  { roll: "CSE103", name: "Arjun",  branch: "CSE", attended: 91, total: 100, status: null },
  { roll: "CSE104", name: "Sneha",  branch: "CSE", attended: 75, total: 100, status: null },
  { roll: "CSE105", name: "Kiran",  branch: "CSE", attended: 60, total: 100, status: null },
  { roll: "CSE106", name: "Divya",  branch: "CSE", attended: 88, total: 100, status: null },
];
