import { useState } from "react";
import Header from "./components/Header";
import Summary from "./components/Summary";
import StudentList from "./components/StudentList";
import { initialStudents } from "./data/students";

function App() {
  const [students, setStudents] = useState(initialStudents);
  const [search, setSearch] = useState("");

  // Attendance % including today's mark (if any)
  const getPercentage = (s) => {
    const attended = s.attended + (s.status === "Present" ? 1 : 0);
    const total = s.total + (s.status ? 1 : 0);
    return Math.round((attended / total) * 100);
  };

  // Mark one student Present/Absent (clicking the same status again undoes it)
  const handleMark = (roll, status) => {
    setStudents((prev) =>
      prev.map((s) =>
        s.roll === roll ? { ...s, status: s.status === status ? null : status } : s
      )
    );
  };

  // Update multiple records at once
  const markAll = (status) => {
    setStudents((prev) => prev.map((s) => ({ ...s, status })));
  };

  const resetAttendance = () => setStudents(initialStudents);

  // Search by name or roll number
  const q = search.trim().toLowerCase();
  const filtered = students.filter(
    (s) => s.name.toLowerCase().includes(q) || s.roll.toLowerCase().includes(q)
  );

  // Summary values (calculated from state, so they update automatically)
  const present = students.filter((s) => s.status === "Present").length;
  const absent = students.filter((s) => s.status === "Absent").length;
  const eligible = students.filter((s) => getPercentage(s) >= 75).length;

  return (
    <div className="app">
      <Header title="Student Attendance Management System" />

      <main className="container">
        <Summary
          total={students.length}
          present={present}
          absent={absent}
          eligible={eligible}
          notEligible={students.length - eligible}
        />

        <div className="toolbar">
          <input
            type="text"
            placeholder="Search by name or roll number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button className="btn present" onClick={() => markAll("Present")}>All Present</button>
          <button className="btn absent" onClick={() => markAll("Absent")}>All Absent</button>
          <button className="btn reset" onClick={resetAttendance}>Reset Attendance</button>
        </div>

        <StudentList
          students={filtered}
          getPercentage={getPercentage}
          onMark={handleMark}
        />
      </main>
    </div>
  );
}

export default App;
