# attendance-management

## Setup
1. Install Node.js (https://nodejs.org) and VS Code.
2. In this folder run:
   npm install
   npm run dev
3. Open http://localhost:5173

## Created from scratch with
npm create vite@latest attendance-management -- --template react
