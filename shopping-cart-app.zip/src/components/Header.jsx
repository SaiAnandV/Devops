import './Header.css'

function Header({ cartItemCount }) {
  return (
    <header className="header">
      <div className="brand">ShopEasy</div>

      <nav>
        <a href="#home">Home</a>
        <a href="#products">Products</a>
        <a href="#cart">Cart</a>
        <a href="#about">About</a>
      </nav>

      <div className="cart-badge">🛒 Cart: {cartItemCount}</div>
    </header>
  )
}

export default Header