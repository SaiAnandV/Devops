import './Cart.css'

function Cart({
  cart,
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
  clearCart
}) {
  const totalPrice = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  )

  return (
    <section className="cart-section" id="cart">
      <div className="cart-heading">
        <div>
          <p className="section-label">YOUR SHOPPING CART</p>
          <h2>Shopping Cart</h2>
        </div>

        {cart.length > 0 && (
          <button className="clear-button" onClick={clearCart}>
            Clear Cart
          </button>
        )}
      </div>

      {cart.length === 0 ? (
        <div className="empty-cart">
          <div className="empty-icon">🛒</div>
          <h3>Cart is Empty</h3>
          <p>Add some products to your cart to get started.</p>
        </div>
      ) : (
        <>
          <div className="cart-items">
            {cart.map((item) => (
              <div className="cart-item" key={item.id}>
                <img src={item.image} alt={item.name} />

                <div className="cart-details">
                  <h3>{item.name}</h3>
                  <p>Price: ₹{item.price}</p>

                  <div className="quantity">
                    <button onClick={() => decreaseQuantity(item.id)}>−</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => increaseQuantity(item.id)}>+</button>
                  </div>

                  <p className="subtotal">
                    Subtotal: ₹{item.price * item.quantity}
                  </p>

                  <button
                    className="remove-button"
                    onClick={() => removeFromCart(item.id)}
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="cart-total">
            <span>Total Price</span>
            <strong>₹{totalPrice}</strong>
          </div>
        </>
      )}
    </section>
  )
}

export default Cart