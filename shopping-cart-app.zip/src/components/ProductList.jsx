import ProductCard from './ProductCard'
import './ProductList.css'

function ProductList({ products, addToCart }) {
  return (
    <section className="products-section" id="products">
      <div className="section-heading">
        <div>
          <p className="section-label">OUR PRODUCTS</p>
          <h2>Available Products</h2>
        </div>
        <span>{products.length} Products</span>
      </div>

      <div className="product-list">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            name={product.name}
            price={product.price}
            category={product.category}
            image={product.image}
            addToCart={() => addToCart(product)}
          />
        ))}
      </div>
    </section>
  )
}

export default ProductList