import './Footer.css'

function Footer() {
  return (
    <footer className="footer" id="about">
      <div>
        <strong>ShopEasy</strong>
        <p>Your simple online shopping destination.</p>
      </div>

      <p>© 2026 Online Shopping Application. All rights reserved.</p>
    </footer>
  )
}

export default Footer