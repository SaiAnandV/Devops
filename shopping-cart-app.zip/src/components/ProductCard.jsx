import './ProductCard.css'

function ProductCard({ name, price, category, image, addToCart }) {
  return (
    <article className="product-card">
      <div className="product-image">
        <img src={image} alt={name} />
      </div>

      <div className="product-info">
        <span className="category-tag">{category}</span>
        <h3>{name}</h3>

        <div className="card-bottom">
          <strong>₹{price}</strong>
          <button className="primary" onClick={addToCart}>
            Add to Cart
          </button>
        </div>
      </div>
    </article>
  )
}

export default ProductCard