import { useState } from 'react'
import Header from './components/Header'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import Footer from './components/Footer'

const products = [
  {
    id: 1,
    name: 'Wireless Headphones',
    price: 1499,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500'
  },
  {
    id: 2,
    name: 'Smart Watch',
    price: 2499,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500'
  },
  {
    id: 3,
    name: 'Running Shoes',
    price: 1999,
    category: 'Fashion',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500'
  },
  {
    id: 4,
    name: 'Backpack',
    price: 999,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500'
  },
  {
    id: 5,
    name: 'Sunglasses',
    price: 799,
    category: 'Fashion',
    image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500'
  },
  {
    id: 6,
    name: 'Laptop',
    price: 54999,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500'
  }
]

function App() {
  const [cart, setCart] = useState([])
  const [message, setMessage] = useState('')

  const addToCart = (product) => {
    setCart((currentCart) => {
      const existingProduct = currentCart.find(
        (item) => item.id === product.id
      )

      if (existingProduct) {
        return currentCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }

      return [...currentCart, { ...product, quantity: 1 }]
    })

    setMessage(`${product.name} added to cart!`)

    setTimeout(() => setMessage(''), 2000)
  }

  const removeFromCart = (id) => {
    setCart((currentCart) =>
      currentCart.filter((item) => item.id !== id)
    )
  }

  const increaseQuantity = (id) => {
    setCart((currentCart) =>
      currentCart.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    )
  }

  const decreaseQuantity = (id) => {
    setCart((currentCart) =>
      currentCart
        .map((item) =>
          item.id === id
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    )
  }

  const clearCart = () => setCart([])

  const cartItemCount = cart.reduce(
    (total, item) => total + item.quantity,
    0
  )

  return (
    <div className="app">
      <Header cartItemCount={cartItemCount} />

      <main>
        <section className="hero" id="home">
          <p className="eyebrow">SHOP • ADD • BUY</p>
          <h1>Welcome to Online Shopping</h1>
          <p>Find your favorite products and add them to your shopping cart.</p>
        </section>

        {message && <p className="message success">{message}</p>}

        <ProductList products={products} addToCart={addToCart} />

        <Cart
          cart={cart}
          removeFromCart={removeFromCart}
          increaseQuantity={increaseQuantity}
          decreaseQuantity={decreaseQuantity}
          clearCart={clearCart}
        />
      </main>

      <Footer />
    </div>
  )
}

export default App