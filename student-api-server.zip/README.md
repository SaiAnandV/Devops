# Secure Student Management API

Node.js + Express REST API with JWT authentication.

## Install

```bash
npm install
```

## Run normally

```bash
npm start
```

## Run using Nodemon

```bash
npm run dev
```

Server:

```text
http://localhost:3000
```

## Default admin

Username:

```text
admin
```

Password:

```text
admin123
```

## APIs

### Home

GET `/`

### Register

POST `/register`

```json
{
  "username": "student1",
  "password": "student123",
  "role": "student"
}
```

### Login

POST `/login`

```json
{
  "username": "admin",
  "password": "admin123"
}
```

Copy the JWT token from the response.

For protected APIs use:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

### Get all students

GET `/students`

Authentication required.

### Add student

POST `/students`

Admin authentication required.

```json
{
  "name": "Anand Kumar",
  "age": 21,
  "course": "Computer Science",
  "email": "anand@example.com"
}
```

### Get one student

GET `/students/1`

Authentication required.

### Delete student

DELETE `/students/1`

Admin authentication required.

## Expected errors

Missing token:

```json
{
  "success": false,
  "message": "Unauthorized: Authorization header is missing"
}
```

Invalid token:

```json
{
  "success": false,
  "message": "Unauthorized: Invalid JWT token"
}
```

Expired token:

```json
{
  "success": false,
  "message": "Unauthorized: JWT token has expired"
}
```

Unknown route returns HTTP 404.

Student users can view students, while admin users can add and delete student records.

Note: This assignment stores passwords in memory for demonstration. A real application should hash passwords and store users in a database, and the JWT secret should be kept in environment variables.