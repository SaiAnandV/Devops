const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 3000;
const JWT_SECRET = "student_api_secret_key_2026";
const JWT_EXPIRES_IN = "1h";

app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl}`);
  next();
});

// In-memory users
const users = [
  {
    id: 1,
    username: "admin",
    password: "admin123",
    role: "admin"
  }
];

// In-memory students
let students = [
  {
    id: 1,
    name: "Sai Anand",
    age: 21,
    course: "Computer Science",
    email: "sai@example.com"
  },
  {
    id: 2,
    name: "Rahul Kumar",
    age: 22,
    course: "Information Technology",
    email: "rahul@example.com"
  }
];

let nextUserId = 2;
let nextStudentId = 3;

// Home API
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Welcome to Secure Student API"
  });
});

// Register API
app.post("/register", (req, res) => {
  const { username, password, role = "student" } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: "Username and password are required"
    });
  }

  if (username.length < 3 || password.length < 6) {
    return res.status(400).json({
      success: false,
      message: "Username must have at least 3 characters and password at least 6 characters"
    });
  }

  const existingUser = users.find(
    (user) => user.username === username
  );

  if (existingUser) {
    return res.status(409).json({
      success: false,
      message: "Username already exists"
    });
  }

  const validRole = role === "admin" ? "admin" : "student";

  const newUser = {
    id: nextUserId++,
    username,
    password,
    role: validRole
  };

  users.push(newUser);

  res.status(201).json({
    success: true,
    message: "User registered successfully",
    user: {
      id: newUser.id,
      username: newUser.username,
      role: newUser.role
    }
  });
});

// Login API
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: "Username and password are required"
    });
  }

  const user = users.find(
    (item) =>
      item.username === username &&
      item.password === password
  );

  if (!user) {
    return res.status(401).json({
      success: false,
      message: "Invalid username or password"
    });
  }

  const token = jwt.sign(
    {
      userId: user.id,
      username: user.username,
      role: user.role
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN
    }
  );

  res.json({
    success: true,
    message: "Login successful",
    token,
    expiresIn: JWT_EXPIRES_IN,
    user: {
      id: user.id,
      username: user.username,
      role: user.role
    }
  });
});

// JWT authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized: Authorization header is missing"
    });
  }

  const parts = authHeader.split(" ");

  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return res.status(401).json({
      success: false,
      message: "Unauthorized: Use Authorization: Bearer <JWT_TOKEN>"
    });
  }

  const token = parts[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: JWT token has expired"
      });
    }

    return res.status(401).json({
      success: false,
      message: "Unauthorized: Invalid JWT token"
    });
  }
}

// Admin authorization middleware
function requireAdmin(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({
      success: false,
      message: "Forbidden: Admin access required"
    });
  }

  next();
}

// Protected GET /students
app.get("/students", authenticateToken, (req, res) => {
  res.json({
    success: true,
    user: {
      id: req.user.userId,
      username: req.user.username,
      role: req.user.role
    },
    count: students.length,
    students
  });
});

// Protected POST /students - admin only
app.post(
  "/students",
  authenticateToken,
  requireAdmin,
  (req, res) => {
    const { name, age, course, email } = req.body;

    if (!name || !age || !course || !email) {
      return res.status(400).json({
        success: false,
        message: "Name, age, course and email are required"
      });
    }

    const newStudent = {
      id: nextStudentId++,
      name,
      age,
      course,
      email
    };

    students.push(newStudent);

    res.status(201).json({
      success: true,
      message: "Student added successfully",
      student: newStudent
    });
  }
);

// Protected GET /students/:id
app.get(
  "/students/:id",
  authenticateToken,
  (req, res) => {
    const id = Number(req.params.id);

    if (Number.isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: "Student ID must be a number"
      });
    }

    const student = students.find(
      (item) => item.id === id
    );

    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    res.json({
      success: true,
      student
    });
  }
);

// Protected DELETE /students/:id - bonus
app.delete(
  "/students/:id",
  authenticateToken,
  requireAdmin,
  (req, res) => {
    const id = Number(req.params.id);

    const studentIndex = students.findIndex(
      (item) => item.id === id
    );

    if (studentIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    const deletedStudent = students.splice(
      studentIndex,
      1
    )[0];

    res.json({
      success: true,
      message: "Student deleted successfully",
      student: deletedStudent
    });
  }
);

// 404 middleware
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.method} ${req.originalUrl} not found`
  });
});

// General error middleware
app.use((err, req, res, next) => {
  console.error(err.stack);

  res.status(500).json({
    success: false,
    message: "Internal server error"
  });
});

app.listen(PORT, () => {
  console.log("====================================");
  console.log(" Secure Student Management API");
  console.log("====================================");
  console.log(`Server running at http://localhost:${PORT}`);
  console.log("JWT authentication: Enabled");
  console.log("JWT expiry: 1 hour");
  console.log("Default admin: admin / admin123");
  console.log("====================================");
});